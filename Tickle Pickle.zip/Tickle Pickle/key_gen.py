# encryption/decryption key.

from cryptography.fernet import Fernet
keys = Fernet.generate_key()
print(key)