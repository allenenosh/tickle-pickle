# encrypting the data 

import json
from cryptography.fernet import Fernet

#Encryption key and object
key = b'Ev8znykA0HDuNUwU46qjbHqNc9BO57N5Q2fLl1kMthE='
enc_obj=Fernet(key)

def fun(name,password):
    s = {"username":name,"password":password}
    plain_text = json.dumps(s).encode()
    enc_text = enc_obj.encrypt(plain_text)

    #Write the encrypted data to file.
    with open("users.json","wb") as f:
        f.write(enc_text)

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    yo_fun = fun(u,p)